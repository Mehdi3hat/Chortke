package com.hesab.app
import android.content.Context
import androidx.work.*
import java.util.Calendar
import java.util.concurrent.TimeUnit

class ReminderWorker(c: Context, p: WorkerParameters) : Worker(c, p) {
    override fun doWork(): Result { Notify.reminder(applicationContext); return Result.success() }
}

object Reminder {
    fun schedule(c: Context) {
        val sp = Store.p(c)
        val now = Calendar.getInstance()
        val t = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, sp.getInt("rh", 21)); set(Calendar.MINUTE, sp.getInt("rm", 0)); set(Calendar.SECOND, 0)
            if (before(now)) add(Calendar.DAY_OF_YEAR, 1)
        }
        val req = PeriodicWorkRequestBuilder<ReminderWorker>(24, TimeUnit.HOURS)
            .setInitialDelay(t.timeInMillis - now.timeInMillis, TimeUnit.MILLISECONDS).build()
        WorkManager.getInstance(c).enqueueUniquePeriodicWork("rem", ExistingPeriodicWorkPolicy.UPDATE, req)
    }
}
