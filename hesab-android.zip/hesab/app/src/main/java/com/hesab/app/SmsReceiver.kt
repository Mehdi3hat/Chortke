package com.hesab.app
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import org.json.JSONObject

fun en(s: String): String {
    val sb = StringBuilder()
    for (ch in s) sb.append(when (ch) {
        in '۰'..'۹' -> '0' + (ch - '۰')
        in '٠'..'٩' -> '0' + (ch - '٠')
        else -> ch
    })
    return sb.toString()
}

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val ms = Telephony.Sms.Intents.getMessagesFromIntent(i) ?: return
        val body = ms.joinToString("") { it.messageBody ?: "" }
        val sender = ms.firstOrNull()?.originatingAddress ?: ""
        val t = en(body).replace('ي', 'ی').replace('ك', 'ک').trim()
        val first = t.lineSequence().firstOrNull()?.trim() ?: ""
        val pres = (Store.p(c).getString("pre", "3003,B.QMEHRIRAN,700717") ?: "3003,B.QMEHRIRAN,700717").split(",").map { it.trim() }.filter { it.isNotEmpty() }
        if (pres.none { first.startsWith(it) || sender.startsWith(it, true) }) return
        if (t.contains("رمز")) return
        val u = t.replace(Regex("\\d{4}/\\d{1,2}/\\d{1,2}\\s*-\\s*\\d{1,2}:\\d{2}"), " ")
            .replace(Regex("(?<!\\d)\\d{4}\\s*-\\s*\\d{1,2}:\\d{2}"), " ")
            .replace(Regex("(حساب|مانده)\\s*:?\\s*[\\d,]+"), " ")
        val m2 = Regex("([-+])\\s*([\\d,]{3,})").find(u)
        val m1 = Regex("([\\d,]{3,})\\s*([-+])").find(u)
        val (amt, sign) = when {
            m2 != null -> m2.groupValues[2] to m2.groupValues[1]
            m1 != null -> m1.groupValues[1] to m1.groupValues[2]
            else -> return
        }
        val rial = amt.replace(",", "").toLongOrNull() ?: return
        val id = System.currentTimeMillis().toString() + "_" + (0..999).random()
        val key = Regex("حساب\\s*:?\\s*(\\d+)").find(t)?.groupValues?.get(1) ?: if (Regex("^\\d{6,}$").matches(first)) first else sender
        Store.add(c, JSONObject().put("id", id).put("raw", body).put("sender", sender).put("ts", System.currentTimeMillis()))
        Notify.tx(c, id, rial, sign == "-", key)
    }
}
