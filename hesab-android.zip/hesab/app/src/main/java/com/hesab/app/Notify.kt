package com.hesab.app
import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.RemoteInput
import java.util.Locale

object Notify {
    private fun channel(c: Context, id: String, name: String, imp: Int) {
        c.getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(id, name, imp))
    }
    private fun open(c: Context) = PendingIntent.getActivity(
        c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    fun tx(c: Context, id: String, rial: Long, out: Boolean, key: String) {
        channel(c, "tx", "تراکنش‌ها", NotificationManager.IMPORTANCE_HIGH)
        val nid = id.hashCode() and 0x7fffffff
        val b = NotificationCompat.Builder(c, "tx").setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(String.format(Locale("fa"), "%,d تومان %s", rial / 10, if (out) "برداشت" else "واریز"))
            .setContentText(if (out) "کجا و برای چی خرج کردی؟" else "این پول از کجا اومد؟")
            .setContentIntent(open(c)).setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_HIGH)
        val an = Store.accName(c, key); if (an.isNotEmpty()) b.setSubText(an)
        Store.cats(c, out).take(2).forEachIndexed { k, cat ->
            val i = Intent(c, NoteReceiver::class.java).putExtra("id", id).putExtra("cat", cat).putExtra("nid", nid)
            b.addAction(0, cat, PendingIntent.getBroadcast(c, nid + k + 1, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
        }
        val ri = RemoteInput.Builder("note").setLabel("کجا؟ برای چی؟").build()
        val mut = if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0
        val ni = Intent(c, NoteReceiver::class.java).putExtra("id", id).putExtra("nid", nid)
        b.addAction(NotificationCompat.Action.Builder(android.R.drawable.ic_menu_edit, "یادداشت",
            PendingIntent.getBroadcast(c, nid, ni, PendingIntent.FLAG_UPDATE_CURRENT or mut)).addRemoteInput(ri).build())
        c.getSystemService(NotificationManager::class.java).notify(nid, b.build())
    }

    fun reminder(c: Context) {
        channel(c, "rem", "یادآوری شبانه", NotificationManager.IMPORTANCE_DEFAULT)
        val n = NotificationCompat.Builder(c, "rem").setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("وقت حساب‌کتابه")
            .setContentText("تراکنش‌های بدون توضیح امروز رو ثبت کن.")
            .setContentIntent(open(c)).setAutoCancel(true).build()
        c.getSystemService(NotificationManager::class.java).notify(1, n)
    }
}
