package com.hesab.app
import android.Manifest
import android.app.Activity
import android.app.NotificationManager
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView

class MainActivity : Activity() {
    private lateinit var w: WebView

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        w = WebView(this); setContentView(w)
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.addJavascriptInterface(Bridge(), "Android")
        w.loadUrl("file:///android_asset/index.html")
        val p = mutableListOf(Manifest.permission.RECEIVE_SMS)
        if (Build.VERSION.SDK_INT >= 33) p.add("android.permission.POST_NOTIFICATIONS")
        requestPermissions(p.toTypedArray(), 1)
        Reminder.schedule(this)
    }

    override fun onResume() {
        super.onResume()
        if (::w.isInitialized) w.evaluateJavascript("window.onNative&&window.onNative()", null)
    }

    @Deprecated("back")
    override fun onBackPressed() { super.onBackPressed() }

    inner class Bridge {
        @JavascriptInterface fun inbox(): String {
            getSystemService(NotificationManager::class.java).cancelAll()
            return Store.take(this@MainActivity)
        }
        @JavascriptInterface fun setCats(j: String) { Store.p(this@MainActivity).edit().putString("cats", j).apply() }
        @JavascriptInterface fun setAccs(j: String) { Store.p(this@MainActivity).edit().putString("accs", j).apply() }
        @JavascriptInterface fun setPrefixes(s: String) { Store.p(this@MainActivity).edit().putString("pre", s).apply() }
        @JavascriptInterface fun setReminder(h: Int, m: Int) {
            val sp = Store.p(this@MainActivity)
            if (sp.getInt("rh", -1) != h || sp.getInt("rm", -1) != m) {
                sp.edit().putInt("rh", h).putInt("rm", m).apply(); Reminder.schedule(this@MainActivity)
            }
        }
    }
}
